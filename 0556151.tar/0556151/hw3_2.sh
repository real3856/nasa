#!/bin/sh

url="google.com"
bookTotal=$(cat ~/.mybrowser/bookmark | awk 'END{print NR}')

dialog --title "Terms" --yesno "$(cat ~/.mybrowser/userterm)"  200 100
# yes is 0, no is 1 , esc is 255
result=$?
if [ $result -eq 1 ] ; then
	dialog --title "Apology" --msgbox "sorry" 200 100
       	exit 1;
fi
dialog --title "banana browser" --msgbox "$(w3m -dump google.com.tw)" 200 100

result=$?
while [ "${result}" == "0" ]
do
user_input=$(dialog --title "banana browser" --inputbox $url 20 80 3>&1 1>&2 2>&3 3>&-)

# exit
if test $? -eq 1 
then
	exit 0;

#url
elif echo "$user_input" | grep -Eq '^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$' ; then
	url=$user_input
	dialog --title "banana browser" --msgbox "$(w3m -dump $url)" 200 100;
 
#build command
elif echo "$user_input" | grep -Eq '^/' ; then
	case ${user_input} in
		#######################source##################
		"/S")
			dialog --title "banana browser" --msgbox "$(curl -s -L $url)" 200 100
			;;

		#######################link###################
		"/L")
			links=$(curl -s -L $url | sed -n 's/.*href="\([^"]*\).*/\1/p' | \
			       	awk -v uri="$url" 'BEGIN{v=1} $1~/^\// {$1=uri$1} {print v++,$1}') 
			number=$(dialog --title "banana browser" --menu "Links:" 200 100 25 $links 3>&1 1>&2 2>&3 3>&-) 
			if test $? -eq 0
			then
				url=$(curl -s -L $url | sed -n 's/.*href="\([^"]*\).*/\1/p' | \
				awk -v uri="$url" '$1!~/^http/ {$1=uri$1} NR=='"$number"' {print $1}')
				dialog --title "banana browser" --msgbox "$(w3m -dump $url)" 200 100
			fi
			;;

		######################download##################
		"/D")
			links=$(curl -s -L $url | sed -n 's/.*href="\([^"]*\).*/\1/p' | \
			       	awk -v uri="$url" 'BEGIN{v=1} $1~/^\// {$1=uri$1} {print v++,$1}') 
			number=$(dialog --title "banana browser" --menu "Links:" 200 100 25 $links 3>&1 1>&2 2>&3 3>&-) 
			if test $? -eq 0
			then
				downloadLink=$(curl -s -L $url | sed -n 's/.*href="\([^"]*\).*/\1/p' | \
				awk -v uri="$url" '$1~/^http/ {$1=uri$1} NR=='"$number"' {print $1}')
				if wget -P ~/Downloads $downloadLink ; then
					dialog --title "banana browser" --msgbox "Download success" 200 100
				else
					fail=$(echo "Could not download!" 1>&2)
					dialog --title "banana browser" --msgbox "$fail" 200 100
				fi
			fi
			;;

		######################bookmark#################
		"/B")
			bookmark=`cat ~/.mybrowser/bookmark`
			bookNum=$(dialog  --title "banana browser" --menu "Bookmarks:" 200 100 25 $bookmark 3>&1 1>&2 2>&3 3>&-)
			if test $? -eq 0 
		       	then
				if test $bookNum -eq 1 
				then
					bookTotal=$((bookTotal + 1)) 
					echo "$bookTotal $url" |tee -a ~/.mybrowser/bookmark
				elif test $bookNum -eq 2
				then		
					deleteNum=$(dialog --title "banana browser" --inputbox \
						"delete a bookmark(input:number)\n $bookmark " 200 100  3>&1 1>&2 2>&3 3>&-)
					if test "$deleteNum" -eq 1;
				       	then
						dialog --title "banana browser" --msgbox "Invalid input!" 20 80
					elif test "$deleteNum" -eq 2;
				       	then
						dialog --title "banana browser" --msgbox "Invalid input!" 20 80
					elif test "$deleteNum" -gt "$bookTotal";
				       	then
						dialog --title "banana browser" --msgbox "Invalid input!" 20 80
					else
						cat ~/.mybrowser/bookmark | \
						awk -v del="$deleteNum" 'BEGIN{c=1} $1!=del {print c++,$2}' |tee ~/.mybrowser/bookmark
					fi
					bookTotal=$((bookTotal - 1))
				else
					bm_goto=$(cat ~/.mybrowser/bookmark | \
						awk -v num="$bookNum" 'NR==num {print $2}')
					dialog --title "banana browser" --msgbox "$(w3m -dump $bm_goto)" 200 100
					url=$bm_goto
				fi
			fi	
			;;

		#######################help######################
		"/H")
			help=`cat ~/.mybrowser/help`
			dialog --title "banana broser" --msgbox "$help" 100 50
			;;	
	esac

elif echo "$user_input" | grep -Eq '^!'; then
	cmd=`echo "$user_input" | cut -c 2- `
	if cmdResult=`$cmd`; then
		dialog --title "banana browser" --msgbox "$cmdResult" 200 100
	else
		dialog --title "banana browser" --msgbox "Invalid input \nTry /H for help message." 100 50
	fi
else
	dialog --title "banana browser" --msgbox "Invalid input \nTry /H for help message." 100 50
fi

done
 
