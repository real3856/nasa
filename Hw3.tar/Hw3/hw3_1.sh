#!/bin/sh
ls -AlR | sort -k 5,5 -r -n | awk 'NR<=5 {print NR":"$5" "$9} /^d/ {d+=1};END{print "Dir num :"d} /^-/ {f+=1; t+=$5}; END{print "File num :"f "\nTotal :"t}'

