#!/bin/sh

url="google.com"
bookTotal=$(cat ~/.mybrowser/bookmark | awk 'END{print NR}')

dialog --title "Terms" --yesno "$(cat ~/.mybrowser/userterm)"  200 100
# yes is 0, no is 1 , esc is 255
result=$?
if [ $result -eq 1 ] ; then
	dialog --title "Apology" --msgbox "sorry" 200 100
       	exit 1;
fi
dialog --title "banana browser" --msgbox "$(w3m -dump google.com.tw)" 200 100

result=$?
while [ "${result}" == "0" ]
do
user_input=$(dialog --title "banana browser" --inputbox $url 20 80 3>&1 1>&2 2>&3 3>&-)
out=$?
# exit
if test $out -eq 1 
then
	exit 1
elif test $out -eq 255
then
	exit 255
#url
elif echo "$user_input" | grep -Eq '^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/a-zA-Z0-9_ \.-]*)*\/?$' ; then
	urlTF=$(w3m -dump $user_input)
	if ["$urlTF" == ""];
       	then
		dialog --title "banana browser" --msgbox "Invalid input \nTry /H for help message." 100 50
	else
		url=$user_input
		dialog --title "banana browser" --msgbox "$urlTF" 200 100;
	fi
 
#build command
elif echo "$user_input" | grep -Eq '^/' ; then
	case ${user_input} in
		#######################source##################
		"/S")
			dialog --title "banana browser" --msgbox "$(curl -s -L $url)" 200 100
			;;

		#######################link###################
		"/L")
			links=$(curl -s -L $url | sed -n 's/.*href="\([^"]*\).*/\1/p' | \
			       	awk -v uri="$url" 'BEGIN{v=1} $1~/^\// {$1=uri$1} {print v++,$1}') 
			number=$(dialog --title "banana browser" --menu "Links:" 200 100 25 $links 3>&1 1>&2 2>&3 3>&-) 
			if test $? -eq 0
			then
				url=$(curl -s -L $url | sed -n 's/.*href="\([^"]*\).*/\1/p' | \
				awk -v uri="$url" '$1!~/^http/ {$1=uri"/"$1} NR=='"$number"' {print $1} ')
				dialog --title "banana browser" --msgbox "$(w3m -dump $url)" 200 100
				
			fi
			;;

		######################download##################
		"/D")
			links=$(curl -s -L $url | sed -n 's/.*href="\([^"]*\).*/\1/p' | \
			       	awk -v uri="$url" 'BEGIN{v=1} $1~/^\// {$1=uri$1} {print v++,$1}') 
			number=$(dialog --title "banana browser" --menu "Links:" 200 100 25 $links 3>&1 1>&2 2>&3 3>&-) 
			if test $? -eq 0
			then
				downloadLink=$(curl -s -L $url | sed -n 's/.*href="\([^"]*\).*/\1/p' | \
				awk -v uri="$url" '$1~/^http/ {$1=uri$1} NR=='"$number"' {print $1}')
				if wget -P ~/Downloads $downloadLink ; then
					dialog --title "banana browser" --msgbox "Download success" 200 100
				else
					fail=$(echo "Could not download!" 1>&2)
					dialog --title "banana browser" --msgbox "$fail" 200 100
				fi
			fi
			;;

		######################bookmark#################
		"/B")
			bookmark=`cat ~/.mybrowser/bookmark`
			bookNum=$(dialog  --title "banana browser" --menu "Bookmarks:" 200 100 25 1 "Add_a_bookmark" 2 "Delete_a_bookmark" $bookmark 3>&1 1>&2 2>&3 3>&-)
			if test $? -eq 0 
		       	then
				if test $bookNum -eq 1 
				then
					if [$bookmark -eq ""];
					then
						bookTotal=$((bookTotal + 3)) 
					else
						bookTotal=$(cat ~/.mybrowser/bookmark | awk 'END{print $1}')
						bookTotal=$((bookTotal + 1))
					fi	
					echo "$bookTotal $url" >> ~/.mybrowser/bookmark
				elif test $bookNum -eq 2
				then		
					if [$bookmark -eq ""];
					then
						dialog --msgbox "no bookmark" 200 100
					else
						delbm=$(cat ~/.mybrowser/bookmark | awk '{print NR" "$2}')
						deleteNum=$(dialog --title "banana browser" --menu "delete bookmark" 200 100 25  $delbm 3>&1 1>&2 2>&3 3>&-)
						deleteNum=$((deleteNum+2))	
						if test $? -eq 0
						then
							cat ~/.mybrowser/bookmark | \
							awk -v del="$deleteNum" 'BEGIN{c=3} $1!=del {print c++,$2}' | tee ~/.mybrowser/bookmark
							bookTotal=$((bookTotal -1))
							
						fi
						
					fi
					
				else
					bm_goto=$(cat ~/.mybrowser/bookmark | \
						awk -v num="$bookNum" 'NR==num {print $2}')
					dialog --title "banana browser" --msgbox "$(w3m -dump $bm_goto)" 200 100
					url=$bm_goto
				fi
			fi	
			;;

		#######################help######################
		"/H")
			help=`cat ~/.mybrowser/help`
			dialog --title "banana broser" --msgbox "$help" 100 50
			;;	
	esac

elif echo "$user_input" | grep -Eq '^!'; then
	cmd=`echo "$user_input" | cut -c 2- `
	if cmdResult=`$cmd`; then
		dialog --title "banana browser" --msgbox "$cmdResult" 200 100
	else
		dialog --title "banana browser" --msgbox "Invalid input \nTry /H for help message." 100 50
	fi
else
	
	dialog --title "banana browser" --msgbox "Invalid input \nTry /H for help message." 100 50
fi

if test $? -eq 255
then
	exit 255
fi

done
 
